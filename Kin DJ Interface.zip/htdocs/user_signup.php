<?php
// Start session
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "sql206.infinityfree.com";
    $username = "if0_38680740"; // Default XAMPP username
    $password = "6EF6fw7JxyitEi";
    $dbname = "if0_38680740_usercredentials"; // Ensure this is your database name

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Ensure email and password are set
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = trim($_POST['email']);
        $user_pass = trim($_POST['password']);

        if (!empty($email) && !empty($user_pass)) {
            // Hash the password
            $hashed_password = password_hash($user_pass, PASSWORD_DEFAULT);

            // Check if email already exists
            $sql = "SELECT email FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                echo "<script>alert('Email already registered. Please login.'); window.location.href='user_login.html';</script>";
            } else {
                // Insert into 'users' table
                $stmt->close(); // Close previous statement

                $sql = "INSERT INTO users (email, password_hash) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $email, $hashed_password);

                if ($stmt->execute()) {
                    // Store user email in session and redirect to user dashboard
                    $_SESSION['user_email'] = $email;
                    
                    header("Location: user_login.html");
                    
                    exit();
                } else {
                    echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='user_signup.html';</script>";
                }
            }
        } else {
            echo "<script>alert('Please fill in all fields.'); window.location.href='user_signup.html';</script>";
        }
    } else {
        echo "<script>alert('Invalid form submission.'); window.location.href='user_signup.html';</script>";
    }

    // Close connections
    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Invalid request.'); window.location.href='user_signup.html';</script>";
}
?>
