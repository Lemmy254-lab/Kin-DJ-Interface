<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Please log in to view your requests.");
}

$user_id = $_SESSION['user_id'];

$conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_kindj");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all song requests made by this user
$songQuery = $conn->prepare("SELECT id, song_name FROM song_requests WHERE user_id = ?");
$songQuery->bind_param("i", $user_id);
$songQuery->execute();
$songResult = $songQuery->get_result();
$songQuery->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Kin DJ Interface Menu</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      height: 100vh;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .sidebar {
      width: 250px;
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      position: fixed;
      height: 100%;
    }
    .sidebar h1 {
      font-size: 24px;
      text-align: center;
      margin-bottom: 30px;
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar li {
      margin: 15px 0;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      font-size: 18px;
      display: block;
      padding: 10px;
      border-radius: 5px;
      transition: background-color 0.3s;
    }
    .sidebar a:hover {
      background-color: #34495e;
    }
    .content {
      margin-left: 270px;
      padding: 20px;
      flex-grow: 1;
    }
    .tab-content {
      display: none;
      padding: 20px;
      background-color: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-top: 20px;
    }
    .active {
      display: block;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h1>Kin DJ</h1>
    <ul>
      <li><a href="#" onclick="showTab('request-song')">Request Song</a></li>
      <li><a href="#" onclick="showTab('search')">Search</a></li>
      <li><a href="#" onclick="showTab('playlists')">Playlists</a></li>
      <li><a href="#" onclick="logout()">Logout</a></li>
    </ul>
  </div>
  <div class="content">
    <h2>Welcome to Kin DJ</h2>
    <p>Select an option from the menu to get started.</p>

    <div id="request-song" class="tab-content active">
      <h3>Request a Song</h3>
      <input type="text" id="song-name" placeholder="Enter song name..." />
      <button onclick="requestSong()">Request</button>
      <p id="request-message" style="display:none; color: green;"></p>
    </div>

    <div id="search" class="tab-content">
      <h3>Identify a Song</h3>
      <p>Hum or sing the song you want to identify</p>
      <button onclick="startRecording()">Start Recording</button>
      <p id="search-result" style="margin-top: 10px;"></p>
    </div>

    <div id="playlists" class="tab-content">
      <h3>Playlists</h3>
      <p>Enjoy our curated DJ playlists powered by Spotify:</p>
      <iframe style="border-radius:12px"
        src="https://open.spotify.com/embed/playlist/2m5bdtgrdfiPKJpIbLxfc1?utm_source=generator"
        width="100%" height="352" frameBorder="0" allowfullscreen=""
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy">
      </iframe>
      <br><br>
      <iframe style="border-radius:12px"
        src="https://open.spotify.com/embed/playlist/3Vn8lAupA3UFlqBe6mavHA?utm_source=generator"
        width="100%" height="352" frameBorder="0" allowfullscreen=""
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy">
      </iframe>
    </div>

    <div id="logout" class="tab-content">
      <h3>Logout</h3>
      <p>You have been logged out successfully. Thank you for using Kin DJ!</p>
      <a href="user_login.html">Login Again</a>
    </div>
  </div>

  <script>
    function showTab(tabName) {
      document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
      const selectedTab = document.getElementById(tabName);
      if (selectedTab) {
        selectedTab.classList.add('active');
      } else {
        console.error("Tab not found: " + tabName);
      }
    }

    function logout() {
      localStorage.clear();
      window.location.href = "user_login.html";
    }

    function requestSong() {
      const songInput = document.getElementById("song-name");
      const songName = songInput.value.trim();

      if (songName) {
        fetch("request_song.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: "songName=" + encodeURIComponent(songName),
        })
        .then(response => response.text())
        .then(data => {
          const messageBox = document.getElementById("request-message");
          messageBox.textContent = "Song request sent successfully!";
          messageBox.style.display = "block";

          setTimeout(() => {
            messageBox.style.display = "none";
          }, 3000);

          songInput.value = "";
        })
        .catch(error => console.error("Error:", error));
      } else {
        alert("Please enter a song name.");
      }
    }
  </script>
  <script>
  let mediaRecorder;
  let audioChunks = [];

  function startRecording() {
    audioChunks = [];
    const resultEl = document.getElementById("search-result");
    resultEl.innerText = "🎤 Listening... Hum for about 10–12 seconds.";

    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.start();

      mediaRecorder.ondataavailable = e => {
        audioChunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const reader = new FileReader();

        reader.readAsDataURL(audioBlob);
        reader.onloadend = function () {
          const base64data = reader.result.split(',')[1];
          fetch('acr_identify.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'audio=' + encodeURIComponent(base64data)
          })
          .then(res => res.json())
          .then(data => {
            console.log("ACRCloud response:", data);
            if (data.status && data.status.code === 0 && data.metadata?.music?.length > 0) {
              const song = data.metadata.music[0];
              resultEl.innerText = `🎵 ${song.title} - ${song.artists[0].name}`;
            } else {
              resultEl.innerText = "❌ Could not identify the song. Try humming again.";
            }
          })
          .catch(err => {
            resultEl.innerText = "❌ Error identifying song: " + err;
          });
        };
      };

    // Stop recording after 12 seconds
      setTimeout(() => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      }, 12000);
    }).catch(err => {
      document.getElementById("search-result").innerText = "❌ Microphone access denied or not supported.";
      console.error(err);
    });
  }
  </script>



</body>
</html>

<?php $conn->close(); ?>
