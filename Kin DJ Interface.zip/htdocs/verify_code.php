<?php
session_start();
$conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_usercredentials");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['reset_code']) && isset($_SESSION['reset_email']) && isset($_SESSION['reset_table'])) {
        $reset_code = trim($_POST['reset_code']);
        $email = $_SESSION['reset_email'];
        $table = $_SESSION['reset_table'];

        // Ensure table is valid (to prevent SQL injection)
        if ($table !== "users" && $table !== "admins") {
            echo "<script>alert('Invalid request. Please try again.'); window.location.href='forgot-password.html';</script>";
            exit();
        }

        // Prepare statement
        $stmt = $conn->prepare("SELECT reset_code, reset_code_created_at FROM $table WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        // Ensure at least one matching row exists
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($stored_code, $reset_code_created_at);
            $stmt->fetch();

            $current_time = time();
            $code_expiry_time = strtotime($reset_code_created_at) + (10 * 60); // 10 minutes expiry

            if ($stored_code == $reset_code && $current_time <= $code_expiry_time) {
                $_SESSION['reset_verified'] = true;
                echo "<script>alert('Code verified successfully!'); window.location.href='reset_password.html';</script>";
            } else {
                echo "<script>alert('Invalid or expired reset code.'); window.location.href='verify_code.html';</script>";
            }
        } else {
            echo "<script>alert('Email not found or no reset request.'); window.location.href='forgot_password.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please enter the reset code.'); window.location.href='verify_code.html';</script>";
    }
}

$conn->close();
?>
