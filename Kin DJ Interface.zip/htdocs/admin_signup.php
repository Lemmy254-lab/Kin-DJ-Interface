<?php
// Database connection
$servername = "sql206.infinityfree.com";
$dbUsername = "if0_38680740"; // Change if needed
$dbPassword = "6EF6fw7JxyitEi";
$dbname = "if0_38680740_usercredentials"; // Ensure this is your correct database name

$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form fields are set
if (!isset($_POST['email']) || !isset($_POST['password'])) {
    die("Please fill all fields.");
}

// Get form data
$email = trim($_POST['email']);
$password = trim($_POST['password']);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Check if email already exists in the 'admins' table
$sql = "SELECT id FROM admins WHERE email = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "Email already registered.";
} else {
    // Insert into 'admins' table
    $sql = "INSERT INTO admins (email, password_hash) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $email, $hashedPassword);

    if ($stmt->execute()) {
        echo "Signup successful!";
        header("Location: admin_index.php");
        exit();
    } else {
        die("Error: " . $stmt->error);
    }
}

// Close connections
$stmt->close();
$conn->close();
?>
