<?php
// Connect to the database
$conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_kindj");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch song requests, along with user_id
$sql = "SELECT id, song_name, request_time, user_id FROM song_requests ORDER BY request_time DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Song Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        .delete-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
    <h2>DJ - Song Requests</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Song Name</th>
            <th>Requested At</th>
            <th>Delete</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row["id"] ?></td>
                    <td><?= htmlspecialchars($row["song_name"]) ?></td>
                    <td><?= $row["request_time"] ?></td>
                    <td>
                        <button class="delete-btn" onclick="deleteRequest(<?= $row['id'] ?>)">Delete</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" style="text-align: center;">No song requests yet.</td>
            </tr>
        <?php endif; ?>
    </table>

    <script>
        function deleteRequest(id) {
            if (confirm("Are you sure you want to delete this request?")) {
                fetch("delete_request.php?id=" + id, { method: "GET" })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                })
                .catch(error => console.error("Error:", error));
            }
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>
