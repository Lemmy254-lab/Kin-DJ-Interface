<?php
$servername = "sql206.infinityfree.com";
$username = "if0_38680740"; // default XAMPP username
$password = "6EF6fw7JxyitEi"; // default XAMPP password
$dbname = "if0_38680740_usercredentials"; // your database name for admin

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $admin_pass = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT password_hash FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($admin_pass, $hashed_password)) {
            // Start session and redirect to admin index
            session_start();
            $_SESSION['admin_email'] = $email; 
            header("Location: admin_index.php");
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href='admin_login.html';</script>";
        }
    } else {
        echo "<script>alert('No admin found with that email.'); window.location.href='admin_login.html';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
<?php
$servername = "sql206.infinityfree.com";
$username = "if0_38680740"; // default XAMPP username
$password = "6EF6fw7JxyitEi"; // default XAMPP password
$dbname = "if0_38680740_usercredentials"; // your database name for admin

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $admin_pass = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT password_hash FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($admin_pass, $hashed_password)) {
            // Start session and redirect to admin index
            session_start();
            $_SESSION['admin_email'] = $email; 
            header("Location: admin_index.php");
            exit();
        } else {
            echo "<script>alert('Invalid password.'); window.location.href='admin_login.html';</script>";
        }
    } else {
        echo "<script>alert('No admin found with that email.'); window.location.href='admin_login.html';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
