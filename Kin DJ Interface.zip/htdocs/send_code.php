<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['email'])) {
        $email = trim($_POST['email']);

        // Connect to database
        $conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_usercredentials");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $table = "";

        // Check users table
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $table = "users";
        }
        $stmt->close();

        // If not found, check admins table
        if (empty($table)) {
            $stmt = $conn->prepare("SELECT email FROM admins WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $table = "admins";
            }
            $stmt->close();
        }

        if (!empty($table)) {
            $reset_code = rand(100000, 999999);
            $reset_time = date("Y-m-d H:i:s");

            // Store reset code
            $stmt = $conn->prepare("UPDATE $table SET reset_code = ?, reset_code_created_at = ? WHERE email = ?");
            $stmt->bind_param("sss", $reset_code, $reset_time, $email);
            $stmt->execute();
            $stmt->close();

            // Send email using Brevo API with Brevo's test email
            $apiKey = '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'; // Replace with your Brevo API key
            $senderEmail = 'no-reply@brevo.com'; // Brevo's test email
            $senderName = 'Kin DJ';
            $subject = 'Password Reset Code';
            $htmlContent = "<p>Your password reset code is: <strong>$reset_code</strong></p>";

            $postData = [
                "sender" => ["name" => $senderName, "email" => $senderEmail],
                "to" => [["email" => $email]],
                "subject" => $subject,
                "htmlContent" => $htmlContent
            ];

            $ch = curl_init("https://api.brevo.com/v3/smtp/email");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "accept: application/json",
                "api-key: $apiKey",
                "content-type: application/json"
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode == 201) {
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_table'] = $table;
                echo "<script>alert('Reset code sent to your email.'); window.location.href='verify_code.html';</script>";
            } else {
                echo "<script>alert('Failed to send email.'); window.location.href='forgot-password.html';</script>";
            }
        } else {
            echo "<script>alert('Email not found.'); window.location.href='forgot-password.html';</script>";
        }

        $conn->close();
    } else {
        echo "<script>alert('Please enter your email.'); window.location.href='forgot-password.html';</script>";
    }
}
?>
