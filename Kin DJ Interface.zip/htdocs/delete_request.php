<?php
$conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_kindj");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM song_requests WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Request deleted!";
    } else {
        echo "Error deleting request.";
    }

    $stmt->close();
} else {
    echo "Invalid request ID.";
}

$conn->close();
?>
