<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_kindj");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $songName = $conn->real_escape_string($_POST["songName"]);
    $sql = "INSERT INTO song_requests (song_name) VALUES ('$songName')";

    if ($conn->query($sql) === TRUE) {
        echo "Request added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
