<?php
session_start(); // Start the session

// Database connection
$servername = "sql206.infinityfree.com";
$username = "if0_38680740";
$password = "6EF6fw7JxyitEi";
$dbname = "if0_38680740_usercredentials"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['email']) && !empty($_POST['password'])) {
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $password = trim($_POST['password']);

        // Prepare and execute SQL statement
        $stmt = $conn->prepare("SELECT id, password_hash FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $hashed_password);
            $stmt->fetch();

            // Verify password
            if (password_verify($password, $hashed_password)) {
                // ✅ Store user ID in session
                $_SESSION['user_id'] = $user_id;

                // Optional: Set session timeout (1 hour)
                $_SESSION['timeout'] = time() + 3600;

                // ✅ Optional debug line — remove this later
                // echo "Login successful! user_id = $user_id";

                // Redirect to user dashboard
                header("Location: user_index.php");
                exit();
            } else {
                echo "<script>alert('Invalid password.'); window.location.href='user_login.html';</script>";
            }
        } else {
            echo "<script>alert('No account found. Please sign up.'); window.location.href='user_signup.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please fill in all fields.'); window.location.href='user_login.html';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='user_login.html';</script>";
}

$conn->close();
?>
