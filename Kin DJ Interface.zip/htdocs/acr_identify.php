<?php
// ACRCloud config (Humming project must be enabled under this account)
$host = "identify-eu-west-1.acrcloud.com";
$access_key = "fd13f55b5d5350cd3c936e7bc809b920";
$access_secret = "2skojkbO7EtpQ0YiIat0574kHIuGJdfzn79sFANB";

// Check if audio is provided
if (!isset($_POST['audio'])) {
    echo json_encode(["error" => "No audio data received."]);
    exit;
}

$audio = base64_decode($_POST['audio']);
$timestamp = time();

// Signature setup
$string_to_sign = "POST\n/v1/identify\n$access_key\naudio\n1\n$timestamp";
$signature = base64_encode(hash_hmac("sha1", $string_to_sign, $access_secret, true));

// Request payload
$data = [
    'access_key' => $access_key,
    'sample_bytes' => strlen($audio),
    'sample' => $audio,
    'timestamp' => $timestamp,
    'signature' => $signature,
    'data_type' => 'humming',
    'signature_version' => '1'
];

// cURL request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$host/v1/identify");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

// Output result
header('Content-Type: application/json');
echo $response;
?>
