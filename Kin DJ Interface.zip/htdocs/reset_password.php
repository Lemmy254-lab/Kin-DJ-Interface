<?php
session_start();
$conn = new mysqli("sql206.infinityfree.com", "if0_38680740", "6EF6fw7JxyitEi", "if0_38680740_usercredentials");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user has verified the reset code and table is set
if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_table'])) {
    echo "<script>alert('Unauthorized access. Please request a reset link again.'); window.location.href='forgot-password.html';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        $new_password = trim($_POST['new_password']);
        $confirm_password = trim($_POST['confirm_password']);
        $email = $_SESSION['reset_email'];
        $table = $_SESSION['reset_table'];

        // Determine redirect link based on table
        $redirect_page = ($table == "admins") ? "admin_login.html" : "user_login.html";

        // Check if passwords match
        if ($new_password !== $confirm_password) {
            echo "<script>alert('Passwords do not match. Please try again.'); window.location.href='reset_password.html';</script>";
            exit();
        }

        // Hash the new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Ensure table name is valid (prevent SQL injection)
        if ($table !== 'users' && $table !== 'admins') {
            die("Invalid table name detected.");
        }

        // Update password in the correct table
        $stmt = $conn->prepare("UPDATE $table SET password_hash = ?, reset_code = NULL, reset_code_created_at = NULL WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);
        
        if ($stmt->execute()) {
            // Unset session variables
            unset($_SESSION['reset_email']);
            unset($_SESSION['reset_verified']);
            unset($_SESSION['reset_table']);

            echo "<script>alert('Password reset successful! You can now log in.'); window.location.href='$redirect_page';</script>";
        } else {
            echo "<script>alert('Error updating password. Please try again.'); window.location.href='reset_password.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please fill in all fields.'); window.location.href='reset_password.html';</script>";
    }
}

$conn->close();
?>
